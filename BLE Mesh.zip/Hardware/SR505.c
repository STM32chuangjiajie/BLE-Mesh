#include "SR505.h"
#include "stm32f10x.h"                  // Device header

void SR505_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructrue;
	GPIO_InitStructrue.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructrue.GPIO_Pin = GPIO_Pin_5;
	GPIO_Init(GPIOA,&GPIO_InitStructrue);
}

u8 SR505_Read(void)
{
	return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5);
}
