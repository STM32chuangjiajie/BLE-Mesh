#ifndef __LED_H
#define __LED_H
#include "stm32f10x.h" 

void LED_Init(void);
void LED_ON(void);
void LED_OFF(void);
void LED_Control(u8 data);
u8 LED_Read(void);
#endif
