#include "stm32f10x.h"                  // Device header

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructrue;
	GPIO_InitStructrue.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructrue.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructrue.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructrue);
}

void LED_ON(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_6,Bit_SET);
}

void LED_OFF(void)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_6,Bit_RESET);
}

void LED_Control(u8 data)
{
	GPIO_WriteBit(GPIOA,GPIO_Pin_6,(BitAction)data);
}

u8 LED_Read(void)
{
	return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6);
}
