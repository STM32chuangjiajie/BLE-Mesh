#ifndef __JDY24M_H
#define __JDY24M_H
#include <stdio.h>
#include <string.h>
#include "stm32f10x.h"
#include "DMA.h"

#define AllMember 0xFFFF
#define NO_ACK 0x00

typedef struct{
	u8 len;
	u16 source;
	u16 target;
	u16 data;
	u8 Done;
}RXdata;
extern RXdata Parse_data;

void USART1_Init(void);
void USART1_SendByte(u8 data);
void USART1_SendArr(u8 *data,u8 length);

void JDY24M_Init(void);
void JDY_Send(u8 ack,u16 address,u16 data);
void JDY_SendAllmember(u16 data);
void JDY24M_Parse(void);
#endif
