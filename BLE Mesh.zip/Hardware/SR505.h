#ifndef __SR505_H
#define __SR505_H
#include "stm32f10x.h"  

void SR505_Init(void);
u8 SR505_Read(void);

#endif
