#include "stm32f10x.h"                  // Device header
#include "node_ctrl.h"

int main(void)
{

	delay_init();
	GY302_Init();
	JDY24M_Init();
	LED_Init();
	SR505_Init();
	while(1)
	{
		Automation_control();
//		delay_ms(20);
		Send_data();
//		delay_ms(20);
		Data_Processing();
		delay_ms(20);
	}
	
}